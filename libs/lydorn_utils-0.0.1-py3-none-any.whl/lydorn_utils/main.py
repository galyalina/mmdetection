import geo_utils

if __name__ == '__main__':
    geo_utils.get_polygons_from_osm("test_WGS84.tif")
